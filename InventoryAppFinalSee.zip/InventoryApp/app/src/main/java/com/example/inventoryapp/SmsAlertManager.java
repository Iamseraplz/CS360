package com.example.inventoryapp;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.telephony.SmsManager;

import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public final class SmsAlertManager {

    private static final String PREFERENCES_NAME = "sms_alert_settings";
    private static final String KEY_PHONE_NUMBER = "phone_number";
    private static final String KEY_ENABLED = "alerts_enabled";

    private final Context context;
    private final SharedPreferences preferences;

    public SmsAlertManager(Context context) {
        this.context = context.getApplicationContext();

        preferences = this.context.getSharedPreferences(
                PREFERENCES_NAME,
                Context.MODE_PRIVATE
        );
    }

    // ------------------------------------------------------------
    // Saved alert settings
    // ------------------------------------------------------------

    public String getPhoneNumber() {
        return preferences.getString(KEY_PHONE_NUMBER, "");
    }

    public boolean isEnabled() {
        return preferences.getBoolean(KEY_ENABLED, false);
    }

    public void enableAlerts(String phoneNumber) {
        String normalizedNumber = normalizePhoneNumber(phoneNumber);

        if (!isValidPhoneNumber(normalizedNumber)) {
            throw new IllegalArgumentException(
                    "Enter a phone number with its country code, "
                            + "starting with +."
            );
        }

        preferences.edit()
                .putString(KEY_PHONE_NUMBER, normalizedNumber)
                .putBoolean(KEY_ENABLED, true)
                .apply();
    }

    public void disableAlerts() {
        // Keep the saved number so the user can enable alerts again.
        preferences.edit()
                .putBoolean(KEY_ENABLED, false)
                .apply();
    }

    public static String normalizePhoneNumber(String phoneNumber) {
        if (phoneNumber == null) {
            return "";
        }

        // Allow common formatting characters in the entered number.
        return phoneNumber.trim().replaceAll("[\\s().-]", "");
    }

    public static boolean isValidPhoneNumber(String phoneNumber) {
        String normalizedNumber = normalizePhoneNumber(phoneNumber);

        // Basic international-format check.
        // This cannot confirm that the number exists or receives SMS.
        return normalizedNumber.matches("\\+[1-9][0-9]{6,14}");
    }

    // ------------------------------------------------------------
    // Permission and device checks
    // ------------------------------------------------------------

    public boolean hasPermission() {
        return ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED;
    }

    public boolean supportsSms() {
        return context.getPackageManager().hasSystemFeature(
                PackageManager.FEATURE_TELEPHONY
        );
    }

    // ------------------------------------------------------------
    // Sending an out-of-stock alert
    // ------------------------------------------------------------

    /**
     * Call only after the database successfully saves a change
     * from a positive quantity to zero.
     *
     * SUBMITTED means Android accepted the sending request.
     * It does not confirm that the recipient received the message.
     */
    public SendResult sendOutOfStockAlert(String itemName) {
        if (!isEnabled()) {
            return SendResult.DISABLED;
        }

        if (!supportsSms()) {
            return SendResult.UNAVAILABLE;
        }

        // Check again at send time, because permission can be revoked.
        if (!hasPermission()) {
            return SendResult.NO_PERMISSION;
        }

        String phoneNumber = getPhoneNumber();

        if (!isValidPhoneNumber(phoneNumber)) {
            return SendResult.INVALID_PHONE_NUMBER;
        }

        if (itemName == null || itemName.trim().isEmpty()) {
            return SendResult.FAILED;
        }

        String message =
                "Inventory alert: "
                        + itemName.trim()
                        + " is out of stock. Current quantity: 0.";

        try {
            SmsManager smsManager = getSmsManager();

            if (smsManager == null) {
                return SendResult.UNAVAILABLE;
            }

            ArrayList<String> messageParts =
                    smsManager.divideMessage(message);

            if (messageParts.size() == 1) {
                smsManager.sendTextMessage(
                        phoneNumber,
                        null,
                        messageParts.get(0),
                        null,
                        null
                );
            } else {
                smsManager.sendMultipartTextMessage(
                        phoneNumber,
                        null,
                        messageParts,
                        null,
                        null
                );
            }

            return SendResult.SUBMITTED;

        } catch (SecurityException exception) {
            // Permission or an installation restriction blocked sending.
            return SendResult.NO_PERMISSION;

        } catch (UnsupportedOperationException exception) {
            return SendResult.UNAVAILABLE;

        } catch (IllegalArgumentException exception) {
            return SendResult.FAILED;

        } catch (IllegalStateException exception) {
            return SendResult.FAILED;
        }
    }

    @SuppressWarnings("deprecation")
    private SmsManager getSmsManager() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return context.getSystemService(SmsManager.class);
        }

        // Compatibility path for Android API 23 through 30.
        return SmsManager.getDefault();
    }

    public enum SendResult {
        SUBMITTED,
        DISABLED,
        NO_PERMISSION,
        INVALID_PHONE_NUMBER,
        UNAVAILABLE,
        FAILED
    }
}