package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class InventoryDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory_app.db";
    private static final int DATABASE_VERSION = 1;

    public static final int MAX_QUANTITY = 999999;

    public InventoryDatabaseHelper(Context context) {
        super(
                context.getApplicationContext(),
                DATABASE_NAME,
                null,
                DATABASE_VERSION
        );
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Store password hashes and salts, never readable passwords.
        db.execSQL(
                "CREATE TABLE users (" +
                        "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT NOT NULL UNIQUE, " +
                        "password_hash BLOB NOT NULL, " +
                        "password_salt BLOB NOT NULL, " +
                        "password_iterations INTEGER NOT NULL " +
                        "CHECK(password_iterations > 0)" +
                        ")"
        );

        // Inventory is shared by accounts on this installation.
        db.execSQL(
                "CREATE TABLE inventory (" +
                        "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "name TEXT NOT NULL COLLATE NOCASE UNIQUE " +
                        "CHECK(length(trim(name)) > 0), " +
                        "quantity INTEGER NOT NULL " +
                        "CHECK(quantity >= 0 AND quantity <= 999999), " +
                        "location TEXT NOT NULL DEFAULT ''" +
                        ")"
        );
    }

    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion
    ) {
        // Version 1 has no migrations yet.
        // Future upgrades must preserve existing accounts and inventory.
        throw new IllegalStateException(
                "A database migration is required from version "
                        + oldVersion + " to " + newVersion
        );
    }

    // ------------------------------------------------------------
    // Account operations
    // ------------------------------------------------------------

    public long createUser(
            String username,
            byte[] passwordHash,
            byte[] passwordSalt,
            int passwordIterations
    ) {
        String normalizedUsername = normalizeUsername(username);

        if (normalizedUsername.isEmpty()
                || normalizedUsername.length() > 60) {
            throw new IllegalArgumentException(
                    "Username must contain 1 to 60 characters."
            );
        }

        if (passwordHash == null || passwordHash.length == 0
                || passwordSalt == null || passwordSalt.length < 16
                || passwordIterations <= 0) {
            throw new IllegalArgumentException(
                    "Valid password hash information is required."
            );
        }

        ContentValues values = new ContentValues();
        values.put("username", normalizedUsername);
        values.put("password_hash", passwordHash);
        values.put("password_salt", passwordSalt);
        values.put("password_iterations", passwordIterations);

        // A duplicate username throws a constraint exception.
        // The login screen will handle that with a helpful message.
        return getWritableDatabase().insertOrThrow(
                "users",
                null,
                values
        );
    }

    public UserRecord getUserByUsername(String username) {
        String[] columns = {
                "_id",
                "username",
                "password_hash",
                "password_salt",
                "password_iterations"
        };

        try (Cursor cursor = getReadableDatabase().query(
                "users",
                columns,
                "username = ?",
                new String[]{normalizeUsername(username)},
                null,
                null,
                null
        )) {
            if (!cursor.moveToFirst()) {
                return null;
            }

            return new UserRecord(
                    cursor.getLong(0),
                    cursor.getString(1),
                    cursor.getBlob(2),
                    cursor.getBlob(3),
                    cursor.getInt(4)
            );
        }
    }

    private String normalizeUsername(String username) {
        if (username == null) {
            return "";
        }

        // Usernames are case-insensitive; passwords will not be.
        return username.trim().toLowerCase(Locale.ROOT);
    }

    // ------------------------------------------------------------
    // Inventory operations
    // ------------------------------------------------------------

    public long addItem(
            String name,
            int quantity,
            String location
    ) {
        String cleanName = name == null ? "" : name.trim();
        String cleanLocation = location == null ? "" : location.trim();

        if (cleanName.isEmpty() || cleanName.length() > 80) {
            throw new IllegalArgumentException(
                    "Item name must contain 1 to 80 characters."
            );
        }

        if (cleanLocation.length() > 80) {
            throw new IllegalArgumentException(
                    "Location cannot exceed 80 characters."
            );
        }

        validateQuantity(quantity);

        ContentValues values = new ContentValues();
        values.put("name", cleanName);
        values.put("quantity", quantity);
        values.put("location", cleanLocation);

        return getWritableDatabase().insertOrThrow(
                "inventory",
                null,
                values
        );
    }

    public List<InventoryItem> getAllItems() {
        List<InventoryItem> items = new ArrayList<>();

        try (Cursor cursor = getReadableDatabase().query(
                "inventory",
                new String[]{"_id", "name", "quantity", "location"},
                null,
                null,
                null,
                null,
                "name COLLATE NOCASE ASC"
        )) {
            while (cursor.moveToNext()) {
                items.add(readInventoryItem(cursor));
            }
        }

        return items;
    }

    public InventoryItem getItemById(long itemId) {
        try (Cursor cursor = getReadableDatabase().query(
                "inventory",
                new String[]{"_id", "name", "quantity", "location"},
                "_id = ?",
                new String[]{String.valueOf(itemId)},
                null,
                null,
                null
        )) {
            if (!cursor.moveToFirst()) {
                return null;
            }

            return readInventoryItem(cursor);
        }
    }

    public boolean updateItemQuantity(
            long itemId,
            int newQuantity
    ) {
        validateQuantity(newQuantity);

        ContentValues values = new ContentValues();
        values.put("quantity", newQuantity);

        int updatedRows = getWritableDatabase().update(
                "inventory",
                values,
                "_id = ?",
                new String[]{String.valueOf(itemId)}
        );

        return updatedRows == 1;
    }

    public boolean deleteItem(long itemId) {
        int deletedRows = getWritableDatabase().delete(
                "inventory",
                "_id = ?",
                new String[]{String.valueOf(itemId)}
        );

        return deletedRows == 1;
    }

    private InventoryItem readInventoryItem(Cursor cursor) {
        return new InventoryItem(
                cursor.getLong(0),
                cursor.getString(1),
                cursor.getInt(2),
                cursor.getString(3)
        );
    }

    private void validateQuantity(int quantity) {
        if (quantity < 0 || quantity > MAX_QUANTITY) {
            throw new IllegalArgumentException(
                    "Quantity must be between 0 and " + MAX_QUANTITY + "."
            );
        }
    }

    // ------------------------------------------------------------
    // Objects returned to the rest of the app
    // ------------------------------------------------------------

    public static class InventoryItem {
        public final long id;
        public final String name;
        public final int quantity;
        public final String location;

        public InventoryItem(
                long id,
                String name,
                int quantity,
                String location
        ) {
            this.id = id;
            this.name = name;
            this.quantity = quantity;
            this.location = location;
        }
    }

    public static class UserRecord {
        public final long id;
        public final String username;
        public final byte[] passwordHash;
        public final byte[] passwordSalt;
        public final int passwordIterations;

        public UserRecord(
                long id,
                String username,
                byte[] passwordHash,
                byte[] passwordSalt,
                int passwordIterations
        ) {
            this.id = id;
            this.username = username;
            this.passwordHash = passwordHash;
            this.passwordSalt = passwordSalt;
            this.passwordIterations = passwordIterations;
        }
    }
}