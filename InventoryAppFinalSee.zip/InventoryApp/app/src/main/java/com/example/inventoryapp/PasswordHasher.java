package com.example.inventoryapp;

import org.bouncycastle.crypto.PBEParametersGenerator;
import org.bouncycastle.crypto.digests.SHA256Digest;
import org.bouncycastle.crypto.generators.PKCS5S2ParametersGenerator;
import org.bouncycastle.crypto.params.KeyParameter;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;

public final class PasswordHasher {

    private static final int ITERATIONS = 600000;
    private static final int SALT_LENGTH_BYTES = 16;
    private static final int HASH_LENGTH_BITS = 256;
    private static final int MAX_PASSWORD_LENGTH = 128;

    private static final SecureRandom RANDOM = new SecureRandom();

    private PasswordHasher() {
        // Utility class: no instances are needed.
    }

    /**
     * Creates a salted password hash for a new account.
     * Run this on a background thread, not the screen's main thread.
     */
    public static PasswordHash hashPassword(String password) {
        validatePassword(password);

        // A different random salt is generated for every account.
        byte[] salt = new byte[SALT_LENGTH_BYTES];
        RANDOM.nextBytes(salt);

        byte[] hash = deriveHash(password, salt, ITERATIONS);

        return new PasswordHash(hash, salt, ITERATIONS);
    }

    /**
     * Checks a supplied password against the account's saved hash.
     * Passwords are case-sensitive and are never trimmed.
     */
    public static boolean verifyPassword(
            String password,
            byte[] savedHash,
            byte[] savedSalt,
            int savedIterations
    ) {
        if (password == null
                || password.isEmpty()
                || password.length() > MAX_PASSWORD_LENGTH) {
            return false;
        }

        if (savedHash == null
                || savedHash.length != HASH_LENGTH_BITS / 8
                || savedSalt == null
                || savedSalt.length != SALT_LENGTH_BYTES) {
            return false;
        }

        // Reject invalid or unexpectedly expensive stored parameters.
        if (savedIterations < ITERATIONS
                || savedIterations > 2000000) {
            return false;
        }

        byte[] candidateHash = deriveHash(
                password,
                savedSalt,
                savedIterations
        );

        try {
            return MessageDigest.isEqual(savedHash, candidateHash);
        } finally {
            Arrays.fill(candidateHash, (byte) 0);
        }
    }

    private static byte[] deriveHash(
            String password,
            byte[] salt,
            int iterations
    ) {
        char[] passwordCharacters = password.toCharArray();
        byte[] passwordBytes = null;

        try {
            passwordBytes =
                    PBEParametersGenerator.PKCS5PasswordToUTF8Bytes(
                            passwordCharacters
                    );

            // PBKDF2 with HMAC-SHA256.
            // Use the library directly without replacing Android providers.
            PKCS5S2ParametersGenerator generator =
                    new PKCS5S2ParametersGenerator(new SHA256Digest());

            generator.init(passwordBytes, salt, iterations);

            KeyParameter key = (KeyParameter)
                    generator.generateDerivedParameters(HASH_LENGTH_BITS);

            return key.getKey();
        } finally {
            Arrays.fill(passwordCharacters, '\0');

            if (passwordBytes != null) {
                Arrays.fill(passwordBytes, (byte) 0);
            }
        }
    }

    private static void validatePassword(String password) {
        if (password == null
                || password.isEmpty()
                || password.length() > MAX_PASSWORD_LENGTH) {
            throw new IllegalArgumentException(
                    "Password must contain 1 to 128 characters."
            );
        }
    }

    /**
     * These values go into the database.
     * The original password is not included.
     */
    public static final class PasswordHash {
        public final byte[] hash;
        public final byte[] salt;
        public final int iterations;

        private PasswordHash(
                byte[] hash,
                byte[] salt,
                int iterations
        ) {
            this.hash = hash;
            this.salt = salt;
            this.iterations = iterations;
        }
    }
}