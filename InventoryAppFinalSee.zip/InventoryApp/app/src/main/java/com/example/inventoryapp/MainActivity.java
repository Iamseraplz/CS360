package com.example.inventoryapp;

import android.Manifest;
import android.content.Intent;
import android.database.sqlite.SQLiteConstraintException;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private String currentScreen = "login";
    private String searchQuery = "";
    private String pendingSmsPhoneNumber;

    private long selectedItemId = -1;
    private InventoryDatabaseHelper.InventoryItem selectedItem;

    private InventoryDatabaseHelper databaseHelper;
    private QuantityManager quantityManager;
    private SmsAlertManager smsAlertManager;

    private final ExecutorService databaseExecutor =
            Executors.newSingleThreadExecutor();

    private List<InventoryDatabaseHelper.InventoryItem> inventoryItems =
            new ArrayList<>();

    private final List<View> temporarilyDisabledViews =
            new ArrayList<>();

    private boolean databaseBusy = false;
    private int screenVersion = 0;

    private interface ResultHandler<T> {
        void onResult(T result);
    }

    private static final class StockUpdateResult {
        final QuantityManager.QuantityChange change;
        final SmsAlertManager.SendResult smsResult;

        StockUpdateResult(
                QuantityManager.QuantityChange change,
                SmsAlertManager.SendResult smsResult
        ) {
            this.change = change;
            this.smsResult = smsResult;
        }
    }

    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    granted -> {
                        getPreferences(MODE_PRIVATE)
                                .edit()
                                .putBoolean("smsPermissionRequested", true)
                                .apply();

                        String requestedNumber = pendingSmsPhoneNumber;
                        pendingSmsPhoneNumber = null;

                        if (granted && requestedNumber != null) {
                            smsAlertManager.enableAlerts(requestedNumber);
                            showMessage("Phone number saved. SMS alerts enabled.");
                        } else if (!granted) {
                            showMessage(
                                    "SMS permission was not granted. "
                                            + "Inventory still works."
                            );
                        }

                        if ("sms".equals(currentScreen)) {
                            updateSmsPermissionStatus();
                        }
                    }
            );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        databaseHelper = new InventoryDatabaseHelper(this);
        quantityManager = new QuantityManager(databaseHelper);
        smsAlertManager = new SmsAlertManager(this);

        if (savedInstanceState != null) {
            currentScreen = savedInstanceState.getString("screen", "login");
            selectedItemId = savedInstanceState.getLong("selectedItemId", -1);
            searchQuery = savedInstanceState.getString("searchQuery", "");
            pendingSmsPhoneNumber =
                    savedInstanceState.getString("pendingSmsPhoneNumber");
        }

        showCurrentScreen();

        getOnBackPressedDispatcher().addCallback(
                this,
                new OnBackPressedCallback(true) {
                    @Override
                    public void handleOnBackPressed() {
                        if (databaseBusy) {
                            showMessage("Please wait for this operation.");
                            return;
                        }

                        switch (currentScreen) {
                            case "quantity":
                                showItemDetailsScreen();
                                break;
                            case "details":
                            case "add":
                            case "sms":
                                showInventoryScreen();
                                break;
                            case "inventory":
                                showLoginScreen();
                                break;
                            default:
                                finish();
                                break;
                        }
                    }
                }
        );
    }

    @Override
    protected void onResume() {
        super.onResume();

        if ("sms".equals(currentScreen)
                && findViewById(R.id.smsPermissionStatus) != null) {
            updateSmsPermissionStatus();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putString("screen", currentScreen);
        outState.putLong("selectedItemId", selectedItemId);
        outState.putString("searchQuery", searchQuery);
        outState.putString("pendingSmsPhoneNumber", pendingSmsPhoneNumber);

        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onDestroy() {
        // Finish queued work before closing this activity's database helper.
        databaseExecutor.execute(() -> databaseHelper.close());
        databaseExecutor.shutdown();
        super.onDestroy();
    }

    private void showCurrentScreen() {
        switch (currentScreen) {
            case "inventory":
                showInventoryScreen();
                break;
            case "add":
                showAddItemScreen();
                break;
            case "details":
                showItemDetailsScreen();
                break;
            case "quantity":
                showChangeQuantityScreen();
                break;
            case "sms":
                showSmsSettingsScreen();
                break;
            default:
                showLoginScreen();
                break;
        }
    }

    private void openScreen(int layoutId, String screenName, int rootId) {
        screenVersion++;
        currentScreen = screenName;
        setContentView(layoutId);
        applyInsets(rootId);
    }

    // ------------------------------------------------------------
    // Login and account creation
    // ------------------------------------------------------------

    private void showLoginScreen() {
        openScreen(R.layout.activity_main, "login", R.id.main);

        selectedItem = null;
        selectedItemId = -1;
        searchQuery = "";
        inventoryItems.clear();

        EditText passwordInput = findViewById(R.id.passwordInput);
        passwordInput.setSaveEnabled(false);

        findViewById(R.id.signInButton).setOnClickListener(view ->
                handleAccountAction(false));

        findViewById(R.id.createAccountButton).setOnClickListener(view ->
                handleAccountAction(true));
    }

    private void handleAccountAction(boolean creatingAccount) {
        if (databaseBusy) {
            return;
        }

        EditText usernameInput = findViewById(R.id.usernameInput);
        EditText passwordInput = findViewById(R.id.passwordInput);

        usernameInput.setError(null);
        passwordInput.setError(null);

        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString();

        if (username.isEmpty() || username.length() > 60) {
            usernameInput.setError(
                    "Enter a username between 1 and 60 characters"
            );
            usernameInput.requestFocus();
            return;
        }

        if (password.isEmpty() || password.length() > 128) {
            passwordInput.setError(
                    "Enter a password between 1 and 128 characters"
            );
            passwordInput.requestFocus();
            return;
        }

        if (creatingAccount && password.length() < 8) {
            passwordInput.setError(
                    "Use at least 8 characters for a new password"
            );
            passwordInput.requestFocus();
            return;
        }

        showMessage(
                creatingAccount ? "Creating account..." : "Signing in..."
        );

        if (creatingAccount) {
            runDatabaseTask(() -> {
                if (databaseHelper.getUserByUsername(username) != null) {
                    return false;
                }

                PasswordHasher.PasswordHash hash =
                        PasswordHasher.hashPassword(password);

                databaseHelper.createUser(
                        username, hash.hash, hash.salt, hash.iterations
                );
                return true;
            }, created -> {
                if (created) {
                    passwordInput.setText("");
                    passwordInput.requestFocus();
                    showMessage(
                            "Account created. Enter your password to sign in."
                    );
                } else {
                    usernameInput.setError("That username is already taken");
                }
            });
        } else {
            runDatabaseTask(() -> {
                InventoryDatabaseHelper.UserRecord user =
                        databaseHelper.getUserByUsername(username);

                return user != null && PasswordHasher.verifyPassword(
                        password,
                        user.passwordHash,
                        user.passwordSalt,
                        user.passwordIterations
                );
            }, validLogin -> {
                if (validLogin) {
                    passwordInput.setText("");
                    showInventoryScreen();
                } else {
                    passwordInput.setError("Incorrect username or password");
                    passwordInput.requestFocus();
                }
            });
        }
    }

    // ------------------------------------------------------------
    // Inventory loading and searching
    // ------------------------------------------------------------

    private void showInventoryScreen() {
        openScreen(
                R.layout.activity_inventory,
                "inventory",
                R.id.inventoryScreen
        );

        EditText searchInput = findViewById(R.id.searchInput);
        searchInput.setText(searchQuery);

        searchInput.addTextChangedListener(textWatcher(() -> {
            searchQuery = searchInput.getText().toString();
            if (!databaseBusy) {
                renderInventoryRows();
            }
        }));

        findViewById(R.id.addItemButton).setOnClickListener(view ->
                showAddItemScreen());

        findViewById(R.id.smsSettingsButton).setOnClickListener(view ->
                showSmsSettingsScreen());

        clearInventoryRows();
        showTableMessage("Loading inventory...");

        runDatabaseTask(
                () -> databaseHelper.getAllItems(),
                items -> {
                    inventoryItems = items;
                    renderInventoryRows();
                }
        );
    }

    private void clearInventoryRows() {
        TableLayout table = findViewById(R.id.inventoryTable);

        // Preserve the column headings and replace the remaining rows.
        if (table.getChildCount() > 1) {
            table.removeViews(1, table.getChildCount() - 1);
        }
    }

    private void renderInventoryRows() {
        TableLayout table = findViewById(R.id.inventoryTable);
        clearInventoryRows();

        String query = searchQuery.trim().toLowerCase(Locale.ROOT);
        int visibleItems = 0;

        for (InventoryDatabaseHelper.InventoryItem item : inventoryItems) {
            String searchableText = (item.name + " " + item.location)
                    .toLowerCase(Locale.ROOT);

            if (!searchableText.contains(query)) {
                continue;
            }

            TableRow row = (TableRow) getLayoutInflater().inflate(
                    R.layout.item_inventory_row, table, false
            );

            Button nameButton = row.findViewById(R.id.rowItemName);
            TextView quantityText = row.findViewById(R.id.rowItemQuantity);
            Button deleteButton = row.findViewById(R.id.rowDeleteButton);

            String stockStatus =
                    item.quantity == 0 ? "Out of stock" : "In stock";

            nameButton.setText(item.name + "\n" + stockStatus);
            nameButton.setContentDescription(
                    item.name + ", quantity " + item.quantity + ", "
                            + stockStatus + ". View item details"
            );

            quantityText.setText(String.valueOf(item.quantity));
            quantityText.setTextColor(Color.parseColor(
                    item.quantity == 0 ? "#9B2424" : "#16352F"
            ));

            deleteButton.setContentDescription("Delete " + item.name);

            nameButton.setOnClickListener(view -> {
                selectedItemId = item.id;
                showItemDetailsScreen();
            });

            deleteButton.setOnClickListener(view -> confirmDelete(item));

            table.addView(row);
            visibleItems++;
        }

        if (visibleItems == 0) {
            showTableMessage(
                    inventoryItems.isEmpty()
                            ? "No items yet. Tap Add item to get started."
                            : "No matching items. Try another search."
            );
        }
    }

    private void showTableMessage(String message) {
        TableLayout table = findViewById(R.id.inventoryTable);
        TableRow row = new TableRow(this);
        TextView text = new TextView(this);

        TableRow.LayoutParams params = new TableRow.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.span = 3;

        text.setLayoutParams(params);
        text.setText(message);
        text.setTextSize(16);
        text.setTextColor(Color.parseColor("#52635E"));
        text.setPadding(dp(8), dp(20), dp(8), dp(20));

        row.addView(text);
        table.addView(row);
    }

    // ------------------------------------------------------------
    // Adding inventory
    // ------------------------------------------------------------

    private void showAddItemScreen() {
        openScreen(
                R.layout.activity_add_item, "add", R.id.addItemScreen
        );

        findViewById(R.id.cancelAddItemButton).setOnClickListener(view ->
                showInventoryScreen());

        findViewById(R.id.saveItemButton).setOnClickListener(view ->
                saveNewItem());
    }

    private void saveNewItem() {
        EditText nameInput = findViewById(R.id.itemNameInput);
        EditText quantityInput = findViewById(R.id.startingQuantityInput);
        EditText locationInput = findViewById(R.id.locationInput);

        nameInput.setError(null);
        quantityInput.setError(null);
        locationInput.setError(null);

        String name = nameInput.getText().toString().trim();
        String quantityValue = quantityInput.getText().toString().trim();
        String location = locationInput.getText().toString().trim();

        if (name.isEmpty() || name.length() > 80) {
            nameInput.setError(
                    "Enter an item name between 1 and 80 characters"
            );
            nameInput.requestFocus();
            return;
        }

        if (location.length() > 80) {
            locationInput.setError("Use no more than 80 characters");
            locationInput.requestFocus();
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityValue);

            if (quantity < 0
                    || quantity > InventoryDatabaseHelper.MAX_QUANTITY) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException exception) {
            quantityInput.setError("Enter a whole number from 0 to 999999");
            quantityInput.requestFocus();
            return;
        }

        final int startingQuantity = quantity;

        runDatabaseTask(
                () -> databaseHelper.addItem(name, startingQuantity, location),
                newItemId -> {
                    searchQuery = "";
                    showMessage("Item saved.");
                    showInventoryScreen();
                }
        );
    }

    // ------------------------------------------------------------
    // Item details and deletion
    // ------------------------------------------------------------

    private void showItemDetailsScreen() {
        if (selectedItemId < 0) {
            showInventoryScreen();
            return;
        }

        openScreen(
                R.layout.activity_item_details,
                "details",
                R.id.itemDetailsScreen
        );

        TextView name = findViewById(R.id.detailItemName);
        TextView location = findViewById(R.id.detailItemLocation);
        TextView quantity = findViewById(R.id.detailItemQuantity);
        TextView status = findViewById(R.id.detailStockStatus);

        name.setText("Loading...");
        location.setText("");
        quantity.setText("");
        status.setText("");
        selectedItem = null;

        findViewById(R.id.backToInventoryButton).setOnClickListener(view ->
                showInventoryScreen());

        findViewById(R.id.changeQuantityButton).setOnClickListener(view -> {
            if (selectedItem != null) {
                showChangeQuantityScreen();
            }
        });

        findViewById(R.id.removeItemButton).setOnClickListener(view -> {
            if (selectedItem != null) {
                confirmDelete(selectedItem);
            }
        });

        final long itemId = selectedItemId;

        runDatabaseTask(
                () -> databaseHelper.getItemById(itemId),
                item -> {
                    if (item == null) {
                        showMessage("This item no longer exists.");
                        showInventoryScreen();
                        return;
                    }

                    selectedItem = item;
                    name.setText(item.name);
                    location.setText(
                            item.location.isEmpty()
                                    ? "Not specified" : item.location
                    );
                    quantity.setText(String.valueOf(item.quantity));
                    status.setText(
                            item.quantity == 0 ? "Out of stock" : "In stock"
                    );
                    status.setTextColor(Color.parseColor(
                            item.quantity == 0 ? "#9B2424" : "#00695C"
                    ));
                }
        );
    }

    private void confirmDelete(
            InventoryDatabaseHelper.InventoryItem item
    ) {
        if (databaseBusy) {
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("Delete item?")
                .setMessage(
                        "Delete " + item.name + " from inventory? "
                                + "This cannot be undone."
                )
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (dialog, which) ->
                        runDatabaseTask(
                                () -> databaseHelper.deleteItem(item.id),
                                deleted -> {
                                    showMessage(
                                            deleted
                                                    ? "Item deleted."
                                                    : "This item was already removed."
                                    );
                                    selectedItem = null;
                                    selectedItemId = -1;
                                    showInventoryScreen();
                                }
                        )
                )
                .show();
    }

    // ------------------------------------------------------------
    // Quantity changes and out-of-stock alerts
    // ------------------------------------------------------------

    private void showChangeQuantityScreen() {
        if (selectedItemId < 0) {
            showInventoryScreen();
            return;
        }

        openScreen(
                R.layout.activity_change_quantity,
                "quantity",
                R.id.changeQuantityScreen
        );

        selectedItem = null;

        TextView name = findViewById(R.id.quantityItemName);
        TextView quantity = findViewById(R.id.currentQuantityText);
        TextView newTotal = findViewById(R.id.newQuantityText);
        EditText amountInput = findViewById(R.id.quantityAmountInput);
        RadioGroup actionGroup = findViewById(R.id.quantityActionGroup);

        name.setText("Loading...");
        quantity.setText("");
        newTotal.setText("Enter an amount to preview the total.");

        findViewById(R.id.cancelQuantityButton).setOnClickListener(view ->
                showItemDetailsScreen());

        findViewById(R.id.saveQuantityButton).setOnClickListener(view ->
                saveQuantityChange());

        amountInput.addTextChangedListener(textWatcher(() -> {
            amountInput.setError(null);
            updateQuantityPreview();
        }));

        actionGroup.setOnCheckedChangeListener((group, checkedId) -> {
            amountInput.setError(null);
            updateQuantityPreview();
        });

        final long itemId = selectedItemId;

        runDatabaseTask(
                () -> databaseHelper.getItemById(itemId),
                item -> {
                    if (item == null) {
                        showMessage("This item no longer exists.");
                        showInventoryScreen();
                        return;
                    }

                    selectedItem = item;
                    name.setText(item.name);
                    quantity.setText("Current quantity: " + item.quantity);
                    updateQuantityPreview();
                }
        );
    }

    private boolean isAddingStock() {
        RadioGroup group = findViewById(R.id.quantityActionGroup);
        return group.getCheckedRadioButtonId() == R.id.addStockRadio;
    }

    private void updateQuantityPreview() {
        if (selectedItem == null) {
            return;
        }

        EditText amountInput = findViewById(R.id.quantityAmountInput);
        TextView newTotal = findViewById(R.id.newQuantityText);
        String enteredAmount = amountInput.getText().toString().trim();

        if (enteredAmount.isEmpty()) {
            newTotal.setText("Enter an amount to preview the total.");
            newTotal.setTextColor(Color.parseColor("#52635E"));
            return;
        }

        try {
            int amount = Integer.parseInt(enteredAmount);
            int proposedQuantity = QuantityManager.calculateNewQuantity(
                    selectedItem.quantity, amount, isAddingStock()
            );

            newTotal.setText(
                    proposedQuantity == 0
                            ? "0 — Out of stock"
                            : String.valueOf(proposedQuantity)
            );
            newTotal.setTextColor(Color.parseColor(
                    proposedQuantity == 0 ? "#9B2424" : "#00695C"
            ));
        } catch (NumberFormatException exception) {
            newTotal.setText("Enter a whole number from 1 to 999999.");
            newTotal.setTextColor(Color.parseColor("#9B2424"));
        } catch (IllegalArgumentException exception) {
            newTotal.setText(exception.getMessage());
            newTotal.setTextColor(Color.parseColor("#9B2424"));
        }
    }

    private void saveQuantityChange() {
        if (databaseBusy || selectedItem == null) {
            return;
        }

        EditText amountInput = findViewById(R.id.quantityAmountInput);
        amountInput.setError(null);

        String enteredAmount = amountInput.getText().toString().trim();
        boolean addingStock = isAddingStock();

        int amount;
        try {
            amount = Integer.parseInt(enteredAmount);

            QuantityManager.calculateNewQuantity(
                    selectedItem.quantity, amount, addingStock
            );
        } catch (NumberFormatException exception) {
            amountInput.setError("Enter a whole number from 1 to 999999");
            amountInput.requestFocus();
            return;
        } catch (IllegalArgumentException exception) {
            amountInput.setError(exception.getMessage());
            amountInput.requestFocus();
            return;
        }

        final long itemId = selectedItem.id;
        final int changeAmount = amount;

        runDatabaseTask(() -> {
            // The database transaction finishes before SMS is requested.
            QuantityManager.QuantityChange change =
                    quantityManager.changeQuantity(
                            itemId, changeAmount, addingStock
                    );

            SmsAlertManager.SendResult smsResult =
                    SmsAlertManager.SendResult.DISABLED;

            if (change.becameOutOfStock()) {
                try {
                    smsResult = smsAlertManager.sendOutOfStockAlert(
                            change.itemName
                    );
                } catch (RuntimeException exception) {
                    // An SMS problem must not undo a saved stock change.
                    smsResult = SmsAlertManager.SendResult.FAILED;
                }
            }

            return new StockUpdateResult(change, smsResult);
        }, result -> {
            showMessage("Quantity saved.");
            showItemDetailsScreen();

            if (result.change.becameOutOfStock()) {
                showOutOfStockAlert(
                        result.change.itemName,
                        result.smsResult
                );
            }
        });
    }

    private void showOutOfStockAlert(
            String itemName,
            SmsAlertManager.SendResult result
    ) {
        String smsMessage;

        switch (result) {
            case SUBMITTED:
                smsMessage =
                        "The SMS sending request was submitted. "
                                + "Delivery has not been confirmed.";
                break;
            case NO_PERMISSION:
                smsMessage =
                        "No SMS was sent because permission is "
                                + "denied or restricted.";
                break;
            case INVALID_PHONE_NUMBER:
                smsMessage =
                        "No SMS was sent. Check the saved alert phone number.";
                break;
            case UNAVAILABLE:
                smsMessage = "SMS is unavailable on this device.";
                break;
            case FAILED:
                smsMessage =
                        "The SMS request failed. Your inventory change "
                                + "was still saved.";
                break;
            default:
                smsMessage = "SMS alerts are turned off.";
                break;
        }

        new AlertDialog.Builder(this)
                .setTitle("Out of stock")
                .setMessage(
                        itemName + " has reached zero quantity.\n\n"
                                + smsMessage
                )
                .setPositiveButton("OK", null)
                .show();
    }

    // ------------------------------------------------------------
    // SMS settings and permission
    // ------------------------------------------------------------

    private void showSmsSettingsScreen() {
        openScreen(
                R.layout.activity_sms_settings,
                "sms",
                R.id.smsSettingsScreen
        );

        EditText phoneInput = findViewById(R.id.alertPhoneInput);
        phoneInput.setText(smsAlertManager.getPhoneNumber());

        findViewById(R.id.allowSmsButton).setOnClickListener(view ->
                saveAndEnableSmsAlerts());

        findViewById(R.id.continueWithoutSmsButton)
                .setOnClickListener(view -> {
                    smsAlertManager.disableAlerts();
                    pendingSmsPhoneNumber = null;
                    updateSmsPermissionStatus();
                    showMessage("SMS alerts turned off.");
                });

        findViewById(R.id.backFromSmsButton).setOnClickListener(view ->
                showInventoryScreen());

        updateSmsPermissionStatus();
    }

    private void saveAndEnableSmsAlerts() {
        EditText phoneInput = findViewById(R.id.alertPhoneInput);
        phoneInput.setError(null);

        String phoneNumber = SmsAlertManager.normalizePhoneNumber(
                phoneInput.getText().toString()
        );

        if (!SmsAlertManager.isValidPhoneNumber(phoneNumber)) {
            phoneInput.setError(
                    "Enter a phone number starting with + and its country code"
            );
            phoneInput.requestFocus();
            return;
        }

        if (!smsAlertManager.supportsSms()) {
            showMessage("SMS is unavailable on this device.");
            return;
        }

        if (smsAlertManager.hasPermission()) {
            smsAlertManager.enableAlerts(phoneNumber);
            updateSmsPermissionStatus();
            showMessage("Phone number saved. SMS alerts enabled.");
            return;
        }

        boolean previouslyRequested = getPreferences(MODE_PRIVATE)
                .getBoolean("smsPermissionRequested", false);

        boolean canShowRationale = shouldShowRequestPermissionRationale(
                Manifest.permission.SEND_SMS
        );

        if (previouslyRequested && !canShowRationale) {
            pendingSmsPhoneNumber = null;

            new AlertDialog.Builder(this)
                    .setTitle("SMS permission needed")
                    .setMessage(
                            "Android is not showing another permission prompt. "
                                    + "Check SMS permission in app settings, "
                                    + "then return and tap Save and enable alerts. "
                                    + "Your device may restrict this permission."
                    )
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Open settings", (dialog, which) -> {
                        Intent intent = new Intent(
                                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:" + getPackageName())
                        );
                        startActivity(intent);
                    })
                    .show();
        } else {
            pendingSmsPhoneNumber = phoneNumber;
            smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    private void updateSmsPermissionStatus() {
        TextView status = findViewById(R.id.smsPermissionStatus);
        Button enableButton = findViewById(R.id.allowSmsButton);
        Button disableButton = findViewById(R.id.continueWithoutSmsButton);

        boolean supported = smsAlertManager.supportsSms();
        boolean permitted = smsAlertManager.hasPermission();
        boolean enabled = smsAlertManager.isEnabled();

        enableButton.setText("Save and enable alerts");
        enableButton.setEnabled(supported);
        disableButton.setText("Turn off SMS alerts");
        disableButton.setEnabled(enabled);

        status.setTextColor(Color.parseColor("#52635E"));

        if (!supported) {
            status.setText(
                    "SMS is unavailable on this device. "
                            + "Inventory and in-app warnings still work."
            );
        } else if (enabled && permitted) {
            status.setText(
                    "SMS alerts are enabled for "
                            + smsAlertManager.getPhoneNumber() + "."
            );
            status.setTextColor(Color.parseColor("#00695C"));
        } else if (enabled) {
            status.setText(
                    "SMS alerts cannot be sent because permission is off "
                            + "or restricted. Inventory still works."
            );
        } else if (permitted) {
            status.setText(
                    "SMS alerts are off. Permission is granted. "
                            + "Save a phone number to enable alerts."
            );
        } else {
            status.setText(
                    "SMS alerts are off. Saving and enabling alerts "
                            + "requires SMS permission."
            );
        }
    }

    // ------------------------------------------------------------
    // Background database work
    // ------------------------------------------------------------

    private <T> void runDatabaseTask(
            Callable<T> work,
            ResultHandler<T> handler
    ) {
        if (databaseBusy) {
            return;
        }

        databaseBusy = true;
        temporarilyDisabledViews.clear();
        disableControls(findViewById(android.R.id.content));

        final int startedOnScreen = screenVersion;

        databaseExecutor.execute(() -> {
            try {
                T result = work.call();

                runOnUiThread(() -> {
                    if (!canDeliverResult(startedOnScreen)) {
                        return;
                    }

                    finishDatabaseWork();
                    handler.onResult(result);
                });
            } catch (Exception exception) {
                final String message;

                if (exception instanceof SQLiteConstraintException) {
                    message = "That username or item name is already in use.";
                } else if (exception instanceof IllegalArgumentException) {
                    message = exception.getMessage() == null
                            ? "Check the entered values and try again."
                            : exception.getMessage();
                } else {
                    message = "Unable to complete the database operation. "
                            + "Please try again.";
                }

                runOnUiThread(() -> {
                    if (!canDeliverResult(startedOnScreen)) {
                        return;
                    }

                    finishDatabaseWork();
                    showMessage(message);

                    if ("inventory".equals(currentScreen)) {
                        clearInventoryRows();
                        showTableMessage(
                                "Could not load inventory. "
                                        + "Return to login and try again."
                        );
                    }
                });
            }
        });
    }

    private boolean canDeliverResult(int startedOnScreen) {
        return !isFinishing()
                && !isDestroyed()
                && screenVersion == startedOnScreen;
    }

    private void disableControls(View view) {
        if ((view instanceof Button || view instanceof EditText)
                && view.isEnabled()) {
            view.setEnabled(false);
            temporarilyDisabledViews.add(view);
        }

        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int index = 0; index < group.getChildCount(); index++) {
                disableControls(group.getChildAt(index));
            }
        }
    }

    private void finishDatabaseWork() {
        for (View view : temporarilyDisabledViews) {
            view.setEnabled(true);
        }

        temporarilyDisabledViews.clear();
        databaseBusy = false;
    }

    // ------------------------------------------------------------
    // Shared helpers
    // ------------------------------------------------------------

    private TextWatcher textWatcher(Runnable action) {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(
                    CharSequence text, int start, int count, int after
            ) {
            }

            @Override
            public void onTextChanged(
                    CharSequence text, int start, int before, int count
            ) {
                action.run();
            }

            @Override
            public void afterTextChanged(Editable text) {
            }
        };
    }

    private int dp(int value) {
        return Math.round(
                value * getResources().getDisplayMetrics().density
        );
    }

    private void showMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void applyInsets(int rootId) {
        View root = findViewById(rootId);

        ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
            Insets spacing = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars()
                            | WindowInsetsCompat.Type.ime()
            );

            view.setPadding(
                    spacing.left,
                    spacing.top,
                    spacing.right,
                    spacing.bottom
            );

            return insets;
        });

        ViewCompat.requestApplyInsets(root);
    }
}