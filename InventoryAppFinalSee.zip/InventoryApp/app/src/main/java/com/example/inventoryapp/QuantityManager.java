package com.example.inventoryapp;

import android.database.sqlite.SQLiteDatabase;

public final class QuantityManager {

    private final InventoryDatabaseHelper databaseHelper;

    public QuantityManager(InventoryDatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    /**
     * Calculates a proposed total without changing the database.
     */
    public static int calculateNewQuantity(
            int currentQuantity,
            int amount,
            boolean addingStock
    ) {
        if (currentQuantity < 0
                || currentQuantity > InventoryDatabaseHelper.MAX_QUANTITY) {
            throw new IllegalArgumentException(
                    "The current quantity is invalid."
            );
        }

        if (amount < 1
                || amount > InventoryDatabaseHelper.MAX_QUANTITY) {
            throw new IllegalArgumentException(
                    "Enter an amount between 1 and 999999."
            );
        }

        long newQuantity = addingStock
                ? (long) currentQuantity + amount
                : (long) currentQuantity - amount;

        if (newQuantity < 0) {
            throw new IllegalArgumentException(
                    "You cannot subtract more stock than you have."
            );
        }

        if (newQuantity > InventoryDatabaseHelper.MAX_QUANTITY) {
            throw new IllegalArgumentException(
                    "The total cannot exceed 999999."
            );
        }

        return (int) newQuantity;
    }

    /**
     * Reads the latest quantity and saves the change in one transaction.
     * Call this method on the database background thread.
     */
    public QuantityChange changeQuantity(
            long itemId,
            int amount,
            boolean addingStock
    ) {
        SQLiteDatabase database = databaseHelper.getWritableDatabase();

        database.beginTransaction();

        try {
            InventoryDatabaseHelper.InventoryItem item =
                    databaseHelper.getItemById(itemId);

            if (item == null) {
                throw new IllegalArgumentException(
                        "This item no longer exists."
                );
            }

            int newQuantity = calculateNewQuantity(
                    item.quantity,
                    amount,
                    addingStock
            );

            boolean updated = databaseHelper.updateItemQuantity(
                    itemId,
                    newQuantity
            );

            if (!updated) {
                throw new IllegalStateException(
                        "The quantity could not be saved."
                );
            }

            QuantityChange result = new QuantityChange(
                    item.id,
                    item.name,
                    item.quantity,
                    newQuantity
            );

            database.setTransactionSuccessful();

            return result;
        } finally {
            database.endTransaction();
        }
    }

    /**
     * Describes a saved change, including whether stock just reached zero.
     */
    public static final class QuantityChange {

        public final long itemId;
        public final String itemName;
        public final int previousQuantity;
        public final int newQuantity;

        private QuantityChange(
                long itemId,
                String itemName,
                int previousQuantity,
                int newQuantity
        ) {
            this.itemId = itemId;
            this.itemName = itemName;
            this.previousQuantity = previousQuantity;
            this.newQuantity = newQuantity;
        }

        public boolean becameOutOfStock() {
            return previousQuantity > 0 && newQuantity == 0;
        }
    }
}